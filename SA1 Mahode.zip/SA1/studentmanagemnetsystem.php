<?php


declare(strict_types=1);
session_start();

// --- Setup JSON "database" ---
$dataFile = __DIR__ . '/students.json';

function initData(): array {
    return [
        'next_ids' => ['users' => 1, 'classes' => 1, 'students' => 1, 'results' => 1],
        'users' => [],
        'classes' => [],
        'students' => [],
        'results' => [],
    ];
}

function loadData(): array {
    global $dataFile;
    if (!file_exists($dataFile)) {
        return initData();
    }
    $json = @file_get_contents($dataFile);
    if ($json === false) return initData();
    $data = json_decode($json, true);
    if (!is_array($data)) return initData();
    // ensure structure
    foreach (['next_ids','users','classes','students','results'] as $k) {
        if (!array_key_exists($k, $data)) {
            $data = array_merge(initData(), $data);
        }
    }
    return $data;
}

function saveData(array $data): bool {
    global $dataFile;
    $tmp = $dataFile . '.tmp';
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) return false;
    if (file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    return rename($tmp, $dataFile);
}

// --- Helper: JSON responses ---
function jsonResponse($data) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

// --- Auth helpers ---
function currentUserId(): ?int {
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
}

function currentUsername(): ?string {
    return $_SESSION['username'] ?? null;
}

function requireAuth() {
    if (!currentUserId()) jsonResponse(['success'=>false, 'message'=>'Authentication required', 'need_login' => true]);
}

// --- Helper utilities for in-memory store ---
function findById(array $items, int $id): ?array {
    foreach ($items as $it) if ((int)$it['id'] === $id) return $it;
    return null;
}

function findIndexById(array $items, int $id): int {
    foreach ($items as $i => $it) if ((int)$it['id'] === $id) return $i;
    return -1;
}

function findUserByUsername(array $users, string $username): ?array {
    foreach ($users as $u) if (strcasecmp($u['username'], $username) === 0) return $u;
    return null;
}

// --- Simple PDF generator (one page, built-in Helvetica) ---
function pdfEscape($s) {
    return str_replace(['\\','(' ,')'], ['\\\\','\\(', '\\)'], $s);
}
function createSimplePdf(string $title, array $lines): string {
    // build content stream
    $y = 760;
    $lineHeight = 14;
    $contentLines = ["BT /F1 12 Tf 50 $y Td (" . pdfEscape($title) . ") Tj"];
    $y -= $lineHeight + 6;
    foreach ($lines as $ln) {
        $contentLines[] = "0 -$lineHeight TD (" . pdfEscape($ln) . ") Tj";
    }
    $content = implode("\n", $contentLines) . "\nET\n";
    $contentStream = $content;
    $len = strlen($contentStream);

    $objs = [];
    $offset = 0;
    $pdf = "%PDF-1.1\n";
    $offset = strlen($pdf);

    // 1 catalog
    $o1 = "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
    $pdf .= $o1; $offset += strlen($o1);

    // 2 pages
    $o2 = "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n";
    $pdf .= $o2; $offset += strlen($o2);

    // 3 page
    $o3 = "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\nendobj\n";
    $pdf .= $o3; $offset += strlen($o3);

    // 4 font
    $o4 = "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n";
    $pdf .= $o4; $offset += strlen($o4);

    // 5 contents
    $o5_head = "5 0 obj\n<< /Length " . $len . " >>\nstream\n";
    $o5_tail = "\nendstream\nendobj\n";
    $pdf .= $o5_head;
    $offset += strlen($o5_head);
    $pdf .= $contentStream;
    $offset += strlen($contentStream);
    $pdf .= $o5_tail;
    $offset += strlen($o5_tail);

    // xref
    $xrefPos = strlen($pdf);
    $pdf .= "xref\n0 6\n0000000000 65535 f \n";
    // compute positions of objects (we can rough compute by searching)
    $positions = [];
    // find offsets by searching for "1 0 obj", etc.
    for ($i=1;$i<=5;$i++) {
        $needle = "$i 0 obj";
        $pos = strpos($pdf, $needle);
        $positions[$i] = $pos !== false ? $pos : 0;
    }
    for ($i=1;$i<=5;$i++) {
        $pdf .= str_pad((string)$positions[$i], 10, '0', STR_PAD_LEFT) . " 00000 n \n";
    }
    // trailer
    $pdf .= "trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n" . $xrefPos . "\n%%EOF";
    return $pdf;
}

// --- Handle API requests ---
$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? '';

if ($action !== '') {
    try {
        // load current data
        $data = loadData();

        // Provide direct PDF download (GET)
        if ($action === 'download_result_pdf' && $method === 'GET') {
            // require auth
            if (!currentUserId()) {
                header('Content-Type: text/plain; charset=utf-8', true, 403);
                echo 'Authentication required';
                exit;
            }
            $uid = currentUserId();
            $id = (int)($_GET['id'] ?? 0);
            if (!$id) {
                header('Content-Type: text/plain; charset=utf-8', true, 400);
                echo 'Invalid id';
                exit;
            }
            $res = findById($data['results'], $id);
            if ($res === null || (int)($res['user_id'] ?? 0) !== $uid) {
                header('Content-Type: text/plain; charset=utf-8', true, 404);
                echo 'Result not found';
                exit;
            }
            $st = findById($data['students'], (int)$res['student_id']);
            $lines = [];
            if ($st) {
                $lines[] = 'Student: ' . ($st['full_name'] ?? '—');
                $lines[] = 'Student ID: ' . ($st['student_identifier'] ?? '—');
                $lines[] = 'Email: ' . ($st['email'] ?? '—');
                $lines[] = 'Date of birth: ' . ($st['dob'] ?? '—');
                $lines[] = 'Course: ' . ($st['course'] ?? '—');
                $lines[] = 'Enrollment date: ' . ($st['enrollment_date'] ?? '—');
                $lines[] = '';
            }
            $lines[] = 'Subject: ' . ($res['subject'] ?? '—');
            $lines[] = 'Score: ' . (isset($res['score']) ? $res['score'] : '—');
            $lines[] = 'Taken at: ' . ($res['taken_at'] ?? '—');
            $title = 'Grade Report';
            $pdf = createSimplePdf($title, $lines);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="grade_' . $id . '.pdf"');
            echo $pdf;
            exit;
        }

        // Auth: register, login, logout, me
        if ($action === 'register' && $method === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            if ($username === '' || $password === '') jsonResponse(['success'=>false,'message'=>'Username and password required']);
            if (findUserByUsername($data['users'], $username) !== null) jsonResponse(['success'=>false,'message'=>'Username already taken']);
            $id = (int)$data['next_ids']['users'];
            $data['next_ids']['users'] = $id + 1;
            $data['users'][] = ['id'=>$id, 'username'=>$username, 'password_hash'=>password_hash($password, PASSWORD_DEFAULT)];
            if (!saveData($data)) jsonResponse(['success'=>false,'message'=>'Failed to save data']);
            // auto-login
            $_SESSION['user_id'] = $id;
            $_SESSION['username'] = $username;
            jsonResponse(['success'=>true, 'id'=>$id, 'username'=>$username]);
        }

        if ($action === 'login' && $method === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            if ($username === '' || $password === '') jsonResponse(['success'=>false,'message'=>'Username and password required']);
            $u = findUserByUsername($data['users'], $username);
            if ($u === null || !password_verify($password, $u['password_hash'])) jsonResponse(['success'=>false,'message'=>'Invalid credentials']);
            $_SESSION['user_id'] = (int)$u['id'];
            $_SESSION['username'] = $u['username'];
            jsonResponse(['success'=>true, 'id'=>$u['id'], 'username'=>$u['username']]);
        }

        if ($action === 'logout' && $method === 'POST') {
            session_unset();
            session_destroy();
            jsonResponse(['success'=>true]);
        }

        if ($action === 'me') {
            $uid = currentUserId();
            if (!$uid) jsonResponse(['success'=>true,'user'=>null]);
            jsonResponse(['success'=>true,'user'=>['id'=>$uid,'username'=>currentUsername()]]);
        }

        // From here require auth for data operations
        requireAuth();
        $uid = currentUserId();

        if ($action === 'list_classes') {
            // sort by name, only classes owned by user
            $classes = array_values(array_filter($data['classes'], function($c) use ($uid){ return isset($c['user_id']) && (int)$c['user_id'] === $uid; }));
            usort($classes, function($a,$b){ return strcasecmp($a['name'] ?? '', $b['name'] ?? ''); });
            jsonResponse(['success' => true, 'classes' => $classes]);
        }

        if ($action === 'add_class' && $method === 'POST') {
            $name = trim($_POST['name'] ?? '');
            if ($name === '') jsonResponse(['success' => false, 'message' => 'Class name required']);
            // uniqueness per-user
            foreach ($data['classes'] as $c) {
                if ((int)($c['user_id'] ?? 0) === $uid && strcasecmp($c['name'], $name) === 0) jsonResponse(['success' => false, 'message' => 'Class already exists']);
            }
            $id = (int)$data['next_ids']['classes'];
            $data['next_ids']['classes'] = $id + 1;
            $data['classes'][] = ['id' => $id, 'name' => $name, 'user_id' => $uid];
            if (!saveData($data)) jsonResponse(['success' => false, 'message' => 'Failed to save data']);
            jsonResponse(['success' => true, 'id' => $id]);
        }

        if ($action === 'delete_class' && $method === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) jsonResponse(['success' => false, 'message' => 'Invalid id']);
            $idx = findIndexById($data['classes'], $id);
            if ($idx === -1) jsonResponse(['success' => false, 'message' => 'Class not found']);
            if ((int)($data['classes'][$idx]['user_id'] ?? 0) !== $uid) jsonResponse(['success'=>false,'message'=>'Not authorized']);
            array_splice($data['classes'], $idx, 1);
            // set students' class_id to null for this user
            foreach ($data['students'] as &$s) {
                if ((int)($s['user_id'] ?? 0) === $uid && isset($s['class_id']) && (int)$s['class_id'] === $id) $s['class_id'] = null;
            }
            unset($s);
            if (!saveData($data)) jsonResponse(['success' => false, 'message' => 'Failed to save data']);
            jsonResponse(['success' => true]);
        }

        if ($action === 'list_students') {
            $students = array_values(array_filter($data['students'], function($s) use ($uid){ return (int)($s['user_id'] ?? 0) === $uid; }));
            usort($students, function($a,$b){
                $na = $a['full_name'] ?? ''; $nb = $b['full_name'] ?? '';
                return strcasecmp($na,$nb);
            });
            // attach class_name
            $classesById = [];
            foreach ($data['classes'] as $c) if ((int)($c['user_id'] ?? 0) === $uid) $classesById[$c['id']] = $c['name'];
            foreach ($students as &$s) {
                $s['class_id'] = isset($s['class_id']) && $s['class_id'] !== '' ? $s['class_id'] : null;
                $s['class_name'] = $s['class_id'] ? ($classesById[$s['class_id']] ?? null) : null;
            }
            unset($s);
            jsonResponse(['success' => true, 'students' => $students]);
        }

        if ($action === 'add_student' && $method === 'POST') {
            $full_name = trim($_POST['full_name'] ?? '');
            $student_identifier = trim($_POST['student_identifier'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $dob = trim($_POST['dob'] ?? '');
            $course = trim($_POST['course'] ?? '');
            $enrollment_date = trim($_POST['enrollment_date'] ?? '');
            $class_id = isset($_POST['class_id']) && $_POST['class_id'] !== '' ? (int)$_POST['class_id'] : null;
            if ($full_name === '' || $student_identifier === '') jsonResponse(['success' => false, 'message' => 'Full name and Student ID required']);
            // optional: ensure class exists for this user when provided
            if ($class_id !== null) {
                $found = findById($data['classes'], $class_id);
                if ($found === null || (int)($found['user_id'] ?? 0) !== $uid) jsonResponse(['success' => false, 'message' => 'Class not found']);
            }
            $id = (int)$data['next_ids']['students'];
            $data['next_ids']['students'] = $id + 1;
            $data['students'][] = [
                'id'=>$id,
                'full_name'=>$full_name,
                'student_identifier'=>$student_identifier,
                'email'=>$email,
                'dob'=>$dob,
                'course'=>$course,
                'enrollment_date'=>$enrollment_date,
                'class_id'=>$class_id,
                'user_id'=>$uid
            ];
            if (!saveData($data)) jsonResponse(['success' => false, 'message' => 'Failed to save data']);
            jsonResponse(['success' => true, 'id' => $id]);
        }

        if ($action === 'update_student' && $method === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            $full_name = trim($_POST['full_name'] ?? '');
            $student_identifier = trim($_POST['student_identifier'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $dob = trim($_POST['dob'] ?? '');
            $course = trim($_POST['course'] ?? '');
            $enrollment_date = trim($_POST['enrollment_date'] ?? '');
            $class_id = isset($_POST['class_id']) && $_POST['class_id'] !== '' ? (int)$_POST['class_id'] : null;
            if (!$id || $full_name === '' || $student_identifier === '') jsonResponse(['success' => false, 'message' => 'Invalid data']);
            $idx = findIndexById($data['students'], $id);
            if ($idx === -1) jsonResponse(['success' => false, 'message' => 'Student not found']);
            if ((int)($data['students'][$idx]['user_id'] ?? 0) !== $uid) jsonResponse(['success'=>false,'message'=>'Not authorized']);
            if ($class_id !== null) {
                $found = findById($data['classes'], $class_id);
                if ($found === null || (int)($found['user_id'] ?? 0) !== $uid) jsonResponse(['success' => false, 'message' => 'Class not found']);
            }
            $data['students'][$idx]['full_name'] = $full_name;
            $data['students'][$idx]['student_identifier'] = $student_identifier;
            $data['students'][$idx]['email'] = $email;
            $data['students'][$idx]['dob'] = $dob;
            $data['students'][$idx]['course'] = $course;
            $data['students'][$idx]['enrollment_date'] = $enrollment_date;
            $data['students'][$idx]['class_id'] = $class_id;
            if (!saveData($data)) jsonResponse(['success' => false, 'message' => 'Failed to save data']);
            jsonResponse(['success' => true]);
        }

        if ($action === 'delete_student' && $method === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) jsonResponse(['success' => false, 'message' => 'Invalid id']);
            $idx = findIndexById($data['students'], $id);
            if ($idx === -1) jsonResponse(['success' => false, 'message' => 'Student not found']);
            if ((int)($data['students'][$idx]['user_id'] ?? 0) !== $uid) jsonResponse(['success'=>false,'message'=>'Not authorized']);
            array_splice($data['students'], $idx, 1);
            // cascade delete results owned by this user for that student
            $data['results'] = array_values(array_filter($data['results'], function($r) use ($id, $uid){ return ((int)$r['student_id'] !== $id) || ((int)($r['user_id'] ?? 0) !== $uid); }));
            if (!saveData($data)) jsonResponse(['success' => false, 'message' => 'Failed to save data']);
            jsonResponse(['success' => true]);
        }

        if ($action === 'list_results') {
            $results = array_values(array_filter($data['results'], function($r) use ($uid){ return (int)($r['user_id'] ?? 0) === $uid; }));
            // attach student info and class_name
            $studentsById = [];
            foreach ($data['students'] as $s) if ((int)($s['user_id'] ?? 0) === $uid) $studentsById[$s['id']] = $s;
            $classesById = [];
            foreach ($data['classes'] as $c) if ((int)($c['user_id'] ?? 0) === $uid) $classesById[$c['id']] = $c['name'];
            foreach ($results as &$r) {
                $sid = (int)$r['student_id'];
                $st = $studentsById[$sid] ?? null;
                $r['student_name'] = $st['full_name'] ?? null;
                $r['student_identifier'] = $st['student_identifier'] ?? null;
                $r['class_name'] = ($st && isset($st['class_id']) && $st['class_id']) ? ($classesById[$st['class_id']] ?? null) : null;
            }
            unset($r);
            usort($results, function($a,$b){
                return strcmp($b['taken_at'] ?? '', $a['taken_at'] ?? '');
            });
            jsonResponse(['success' => true, 'results' => $results]);
        }

        if ($action === 'add_result' && $method === 'POST') {
            $student_id = (int)($_POST['student_id'] ?? 0);
            $subject = trim($_POST['subject'] ?? '');
            $score = $_POST['score'] !== '' ? (float)$_POST['score'] : null;
            if (!$student_id || $subject === '' || $score === null) jsonResponse(['success' => false, 'message' => 'Invalid data']);
            $st = findById($data['students'], $student_id);
            if ($st === null || (int)($st['user_id'] ?? 0) !== $uid) jsonResponse(['success' => false, 'message' => 'Student not found']);
            $id = (int)$data['next_ids']['results'];
            $data['next_ids']['results'] = $id + 1;
            $data['results'][] = ['id'=>$id, 'student_id'=>$student_id, 'subject'=>$subject, 'score'=>$score, 'taken_at'=>date('Y-m-d H:i:s'), 'user_id'=>$uid];
            if (!saveData($data)) jsonResponse(['success' => false, 'message' => 'Failed to save data']);
            jsonResponse(['success' => true, 'id' => $id]);
        }

        if ($action === 'update_result' && $method === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            $subject = trim($_POST['subject'] ?? '');
            $score = $_POST['score'] !== '' ? (float)$_POST['score'] : null;
            if (!$id || $subject === '' || $score === null) jsonResponse(['success' => false, 'message' => 'Invalid data']);
            $idx = findIndexById($data['results'], $id);
            if ($idx === -1) jsonResponse(['success' => false, 'message' => 'Result not found']);
            if ((int)($data['results'][$idx]['user_id'] ?? 0) !== $uid) jsonResponse(['success'=>false,'message'=>'Not authorized']);
            $data['results'][$idx]['subject'] = $subject;
            $data['results'][$idx]['score'] = $score;
            if (!saveData($data)) jsonResponse(['success' => false, 'message' => 'Failed to save data']);
            jsonResponse(['success' => true]);
        }

        if ($action === 'delete_result' && $method === 'POST') {
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) jsonResponse(['success' => false, 'message' => 'Invalid id']);
            $idx = findIndexById($data['results'], $id);
            if ($idx === -1) jsonResponse(['success' => false, 'message' => 'Result not found']);
            if ((int)($data['results'][$idx]['user_id'] ?? 0) !== $uid) jsonResponse(['success'=>false,'message'=>'Not authorized']);
            array_splice($data['results'], $idx, 1);
            if (!saveData($data)) jsonResponse(['success' => false, 'message' => 'Failed to save data']);
            jsonResponse(['success' => true]);
        }

        // unknown action
        jsonResponse(['success' => false, 'message' => 'Unknown action']);
    } catch (Throwable $e) {
        jsonResponse(['success' => false, 'message' => $e->getMessage()]);
    }
    // end API handling
}

// --- Render HTML UI ---
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Student Management System</title>
<meta name="viewport" content="width=device-width,initial-scale=1" />
<style>
:root{
    --bg: #071726;        /* very dark blue */
    --panel: #0e2a45;     /* deep blue panel */
    --muted: #9fb8cf;     /* soft blue */
    --accent: #d43a3a;    /* red accent */
    --accent-2: #ff5a5a;  /* lighter red */
    --text: #e8f3fb;      /* light text */
    --border: rgba(255,255,255,0.06);
    --glass: rgba(255,255,255,0.02);
    --success: #4fc08d;
}

*{box-sizing:border-box}
html,body{height:100%}
body{
    font-family: "Segoe UI", Roboto, Arial, sans-serif;
    background: linear-gradient(180deg, var(--bg) 0%, #031021 100%);
    color:var(--text);
    max-width:1000px;
    margin:20px auto;
    padding:18px;
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale;
}

/* Header */
header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:14px;
    background: linear-gradient(90deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
    border:1px solid var(--border);
    border-radius:8px;
    box-shadow: 0 6px 18px rgba(2,10,20,0.6);
}
h1{margin:0;color:var(--text);font-size:1.25rem}
.small{color:var(--muted)}

/* Tabs */
.tabs{margin-top:16px;display:flex;gap:8px}
.tabs button{
    background:transparent;
    color:var(--muted);
    border:1px solid transparent;
    padding:8px 12px;
    border-radius:6px;
    cursor:pointer;
    transition:all .18s ease;
    font-weight:600;
}
.tabs button:hover{
    color:var(--text);
    background:rgba(255,255,255,0.02);
    box-shadow:0 4px 10px rgba(2,10,20,0.6);
}
.tabs button.active,
.tabs button:focus{
    color:var(--text);
    background:linear-gradient(180deg, rgba(212,58,58,0.12), rgba(212,58,58,0.06));
    border:1px solid rgba(212,58,58,0.18);
    outline:none;
}

/* Sections / panels */
section{
    margin-top:12px;
    background: linear-gradient(180deg, var(--panel), rgba(14,42,69,0.9));
    padding:14px;
    border-radius:8px;
    border:1px solid var(--border);
    box-shadow: 0 8px 24px rgba(2,10,20,0.6);
}

/* Forms */
form{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
input, select{
    background:var(--glass);
    color:var(--text);
    border:1px solid rgba(255,255,255,0.04);
    padding:8px 10px;
    border-radius:6px;
    min-height:36px;
    transition:box-shadow .12s ease, border-color .12s ease;
}
input:focus, select:focus{
    outline:none;
    box-shadow:0 4px 16px rgba(2,10,20,0.6);
    border-color:rgba(212,58,58,0.6);
}

/* Buttons */
.btn, button{
    background: linear-gradient(180deg, var(--accent), var(--accent-2));
    color: white;
    border: none;
    padding:8px 12px;
    border-radius:6px;
    cursor:pointer;
    font-weight:700;
    box-shadow: 0 6px 18px rgba(212,58,58,0.12);
    transition:transform .08s ease, box-shadow .12s ease, opacity .12s ease;
}
.btn:hover, button:hover{ transform: translateY(-1px); opacity:0.98; }
button[disabled]{ opacity:0.5; cursor:not-allowed; }

/* Auth area adjustments */
#authArea button{
    background:transparent;
    border:1px solid rgba(255,255,255,0.04);
    color:var(--muted);
    padding:6px 8px;
    border-radius:6px;
}
#authArea button:hover{ color:var(--text); border-color:rgba(212,58,58,0.14) }

/* Table */
table{
    width:100%;
    border-collapse:collapse;
    margin-top:8px;
    background:transparent;
    color:var(--text);
}
th, td{
    padding:10px 12px;
    border-bottom:1px solid rgba(255,255,255,0.03);
    text-align:left;
    vertical-align:middle;
}
thead th{
    background:linear-gradient(90deg, rgba(255,255,255,0.02), rgba(0,0,0,0.04));
    font-size:0.95em;
    color:var(--muted);
    border-bottom:1px solid rgba(255,255,255,0.04);
}
tbody tr:nth-child(odd){ background: rgba(255,255,255,0.01) }
tbody tr:hover{ background: rgba(212,58,58,0.03) }

/* Action buttons in tables */
table button{
    background:transparent;
    border:1px solid rgba(255,255,255,0.06);
    color:var(--text);
    padding:6px 8px;
    border-radius:6px;
    font-weight:600;
}
table button:hover{
    background: rgba(212,58,58,0.12);
    border-color: rgba(212,58,58,0.2);
    color:#fff;
}

/* Responsive */
@media (max-width:720px){
    body{padding:12px}
    form{flex-direction:column;align-items:stretch}
    .tabs{flex-wrap:wrap}
    th,td{padding:8px}
}
</style>
</head>
<header>
  <h1>Student Management System</h1>
  <div>
    <span class="small"> Welcome</span>
    <span id="authArea" class="small" style="margin-left:12px"></span>
  </div>
</header>

<div class="tabs">
    <button onclick="show('classes')">Classes</button>
    <button onclick="show('students')">Students</button>
    <button onclick="show('results')">Results</button>
    <button onclick="showAll()">All</button>
</div>

<!-- Classes -->
<section id="classes" style="display:block">
    <h2>Classes</h2>
    <form id="classForm" onsubmit="return addClass();">
        <input name="name" id="className" placeholder="Class name (e.g., Grade 10)" required />
        <button class="btn" type="submit">Add Class</button>
    </form>
    <div id="classesList">Loading classes...</div>
</section>

<!-- Students -->
<section id="students" style="display:none">
    <h2>Students</h2>
    <form id="studentForm" onsubmit="return addStudent();">
        <input id="fullName" placeholder="Full name" required />
        <input id="studentIdentifier" placeholder="Student ID" required />
        <input id="email" placeholder="Email" type="email" />
        <input id="dob" placeholder="Date of Birth (YYYY-MM-DD)" />
        <input id="course" placeholder="Course of Study" />
        <input id="enrollmentDate" placeholder="Enrollment Date (YYYY-MM-DD)" />
        <select id="studentClass"><option value="">-- No class --</option></select>
        <button class="btn" type="submit">Add Student</button>
    </form>
    <div id="studentsList">Loading students...</div>
</section>

<!-- Results -->
<section id="results" style="display:none">
    <h2>Results</h2>
    <form id="resultForm" onsubmit="return addResult();">
        <select id="resultStudent" required><option value="">Select student</option></select>
        <input id="subject" placeholder="Subject" required />
        <input id="score" type="number" step="0.01" placeholder="Score" required />
        <button class="btn" type="submit">Add Result</button>
    </form>
    <div id="resultsList">Loading results...</div>
</section>

<!-- All: combined view of students with full details and their results -->
<section id="all" style="display:none">
    <h2>All Students (Full Information)</h2>
    <div id="allList">Loading all information...</div>
</section>

<script>
    // showAll: show combined "All" section and hide others
    function showAll() {
        document.getElementById('classes').style.display = 'none';
        document.getElementById('students').style.display = 'none';
        document.getElementById('results').style.display = 'none';
        document.getElementById('all').style.display = 'block';
        loadAll();
    }

    // loadAll: fetch students, results and classes and render a full table
    async function loadAll() {
        const [rsResults, rsStudents, rsClasses] = await Promise.allSettled([
            api('list_results'),
            api('list_students'),
            api('list_classes')
        ]);

        // handle students response
        const stRes = rsStudents.status === 'fulfilled' ? rsStudents.value : null;
        if (!stRes || !stRes.success) {
            document.getElementById('allList').textContent = 'Error loading students: ' + (stRes && stRes.message ? stRes.message : 'Request failed');
            return;
        }
        const students = stRes.students || [];

        // results (may fail if not logged in)
        const results = (rsResults.status === 'fulfilled' && rsResults.value && rsResults.value.success) ? rsResults.value.results : [];

        // classes (may fail)
        const classes = (rsClasses.status === 'fulfilled' && rsClasses.value && rsClasses.value.success) ? rsClasses.value.classes : [];
        const classNames = {};
        classes.forEach(c => { classNames[c.id] = c.name; });

        // map results by student id
        const resByStudent = {};
        (results || []).forEach(r => {
            const sid = Number(r.student_id);
            if (!resByStudent[sid]) resByStudent[sid] = [];
            resByStudent[sid].push(r);
        });

        // table rows
        const rows = students.map(s => {
            const sid = s.id;
            const clsName = s.class_name || (s.class_id ? (classNames[s.class_id] || '') : '');
            const resultsHtml = (resByStudent[sid] || []).map(rr =>
                `<div class="small">${escapeHtml(rr.subject)} — ${escapeHtml(String(rr.score))} (${escapeHtml(rr.taken_at)})</div>`
            ).join('') || '<div class="small">No results</div>';

            return `<tr>
                <td>${escapeHtml(s.full_name)}<div class="small">${escapeHtml(s.student_identifier||'')}</div></td>
                <td>${escapeHtml(s.email||'')}</td>
                <td>${escapeHtml(s.dob||'')}</td>
                <td>${escapeHtml(s.course||'')}</td>
                <td>${escapeHtml(s.enrollment_date||'')}</td>
                <td>${escapeHtml(clsName || '—')}</td>
                <td>${resultsHtml}</td>
            </tr>`;
        }).join('');

        document.getElementById('allList').innerHTML =
            `<table>
                 <thead>
                     <tr>
                         <th>Name / ID</th>
                         <th>Email</th>
                         <th>DOB</th>
                         <th>Course</th>
                         <th>Enrollment</th>
                         <th>Class</th>
                         <th>Results</th>
                     </tr>
                 </thead>
                 <tbody>${rows}</tbody>
             </table>`;
    }
</script>

<script>
// JS helper fetch
async function api(action, data = null) {
  const opts = data ? { method: 'POST', body: new URLSearchParams(Object.assign({action}, data)) } : { method: 'GET' };
  const url = data ? '' : '?action=' + encodeURIComponent(action);
  const res = await fetch(url, opts);
  return res.json();
}

function show(name) {
  ['classes','students','results'].forEach(n => document.getElementById(n).style.display = (n===name ? 'block' : 'none'));
  if (name === 'classes') loadClasses();
  if (name === 'students') { loadStudents(); loadClassesIntoSelect(); }
  if (name === 'results') { loadResults(); loadStudentsIntoSelect(); }
}

// Auth UI
async function loadCurrentUser() {
  const r = await api('me');
  const auth = document.getElementById('authArea');
  if (!r.success || !r.user) {
    auth.innerHTML = '<button onclick="loginPrompt()">Login</button><button onclick="registerPrompt()">Register</button>';
  } else {
    auth.innerHTML = `Hello, ${escapeHtml(r.user.username)} <button onclick="logout()">Logout</button>`;
  }
}

async function loginPrompt() {
  const username = prompt('Username');
  if (username === null) return;
  const password = prompt('Password');
  if (password === null) return;
  const r = await api('login', {username, password});
  if (r.success) {
    await loadCurrentUser();
    loadClasses(); loadStudents(); loadResults();
  } else alert('Error: ' + r.message);
}

async function registerPrompt() {
  const username = prompt('Choose username');
  if (username === null) return;
  const password = prompt('Choose password');
  if (password === null) return;
  const r = await api('register', {username, password});
  if (r.success) {
    await loadCurrentUser();
    loadClasses(); loadStudents(); loadResults();
  } else alert('Error: ' + r.message);
}

async function logout() {
  await api('logout', {});
  await loadCurrentUser();
  loadClasses(); loadStudents(); loadResults();
}

// Classes
async function loadClasses() {
  const r = await api('list_classes');
  const container = document.getElementById('classesList');
  if (!r.success) { container.textContent = 'Error: ' + r.message; return; }
  const rows = r.classes.map(c => `<tr><td>${escapeHtml(c.name)}</td>
    <td><button onclick="deleteClass(${c.id})">Delete</button></td></tr>`).join('');
  container.innerHTML = `<table><thead><tr><th>Name</th><th>Action</th></tr></thead><tbody>${rows}</tbody></table>`;
  loadClassesIntoSelect();
}

async function addClass() {
  const name = document.getElementById('className').value.trim();
  if (!name) return false;
  const r = await api('add_class', {name});
  if (r.success) { document.getElementById('className').value=''; loadClasses(); }
  else {
    if (r.need_login) { alert('Please login first'); await loadCurrentUser(); }
    else alert('Error: ' + r.message);
  }
  return false;
}

async function deleteClass(id) {
  if (!confirm('Delete class? Students in this class will be set to no class.')) return;
  const r = await api('delete_class', {id});
  if (r.success) loadClasses();
  else alert('Error: ' + r.message);
}

async function loadClassesIntoSelect() {
  const r = await api('list_classes');
  const sel1 = document.getElementById('studentClass');
  if (!r.success) return;
  sel1.innerHTML = '<option value="">-- No class --</option>' + r.classes.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');
}

// Students
async function loadStudents() {
  const r = await api('list_students');
  const container = document.getElementById('studentsList');
  if (!r.success) { container.textContent = 'Error: ' + r.message; return; }
  const rows = r.students.map(s => `<tr>
    <td>${escapeHtml(s.full_name)}<div class="small">${escapeHtml(s.student_identifier||'')}</div></td>
    <td>${escapeHtml(s.class_name||'—')}<div class="small">${escapeHtml(s.course||'')}</div></td>
    <td>
      <button onclick="editStudent(${s.id},${JSON.stringify(s.full_name)},${JSON.stringify(s.student_identifier)},${JSON.stringify(s.email)},${JSON.stringify(s.dob)},${JSON.stringify(s.course)},${JSON.stringify(s.enrollment_date)},${s.class_id??'null'})">Edit</button>
      <button onclick="deleteStudent(${s.id})">Delete</button>
    </td>
    </tr>`).join('');
  container.innerHTML = `<table><thead><tr><th>Name / ID</th><th>Class / Course</th><th>Action</th></tr></thead><tbody>${rows}</tbody></table>`;
  loadStudentsIntoSelect();
}

async function addStudent() {
  const full_name = document.getElementById('fullName').value.trim();
  const student_identifier = document.getElementById('studentIdentifier').value.trim();
  const email = document.getElementById('email').value.trim();
  const dob = document.getElementById('dob').value.trim();
  const course = document.getElementById('course').value.trim();
  const enrollment_date = document.getElementById('enrollmentDate').value.trim();
  const class_id = document.getElementById('studentClass').value;
  if (!full_name || !student_identifier) return false;
  const r = await api('add_student', {full_name, student_identifier, email, dob, course, enrollment_date, class_id});
  if (r.success) {
    document.getElementById('fullName').value=''; document.getElementById('studentIdentifier').value='';
    document.getElementById('email').value=''; document.getElementById('dob').value='';
    document.getElementById('course').value=''; document.getElementById('enrollmentDate').value='';
    loadStudents();
  }
  else {
    if (r.need_login) { alert('Please login first'); await loadCurrentUser(); }
    else alert('Error: ' + r.message);
  }
  return false;
}

function editStudent(id, fullName, studentId, email, dob, course, enrollmentDate, classId) {
  const fn = prompt('Full name', fullName);
  if (fn === null) return;
  const sid = prompt('Student ID', studentId);
  if (sid === null) return;
  const em = prompt('Email', email ?? '');
  if (em === null) return;
  const db = prompt('Date of Birth (YYYY-MM-DD)', dob ?? '');
  if (db === null) return;
  const cr = prompt('Course of Study', course ?? '');
  if (cr === null) return;
  const ed = prompt('Enrollment Date (YYYY-MM-DD)', enrollmentDate ?? '');
  if (ed === null) return;
  const cid = prompt('Class ID (empty for none)', classId === null ? '' : classId);
  api('update_student', {
    id, full_name: fn.trim(), student_identifier: sid.trim(),
    email: em.trim(), dob: db.trim(), course: cr.trim(), enrollment_date: ed.trim(), class_id: cid
  }).then(r => {
    if (r.success) loadStudents(); else alert('Error: ' + r.message);
  });
}

async function deleteStudent(id) {
  if (!confirm('Delete student and all their results?')) return;
  const r = await api('delete_student', {id});
  if (r.success) loadStudents();
  else alert('Error: ' + r.message);
}

async function loadStudentsIntoSelect() {
  const r = await api('list_students');
  const sel = document.getElementById('resultStudent');
  if (!r.success) return;
  sel.innerHTML = '<option value="">Select student</option>' + r.students.map(s => `<option value="${s.id}">${escapeHtml(s.full_name)} (${escapeHtml(s.student_identifier||'')})${s.class_name? ' — '+escapeHtml(s.class_name):''}</option>`).join('');
}

// Results
async function loadResults() {
  const r = await api('list_results');
  const container = document.getElementById('resultsList');
  if (!r.success) { container.textContent = 'Error: ' + r.message; return; }
  const rows = r.results.map(rw => `<tr>
    <td>${escapeHtml(rw.student_name)}</td>
    <td>${escapeHtml(rw.class_name||'—')}</td>
    <td>${escapeHtml(rw.subject)}</td>
    <td>${Number(rw.score)}</td>
    <td>${escapeHtml(rw.taken_at)}</td>
    <td>
      <button onclick="editResult(${rw.id},${JSON.stringify(rw.subject)},${encodeURIComponent(rw.score)})">Edit</button>
      <button onclick="deleteResult(${rw.id})">Delete</button>
      <button onclick="downloadResult(${rw.id})">Download PDF</button>
    </td>
  </tr>`).join('');
  container.innerHTML = `<table><thead><tr><th>Student</th><th>Class</th><th>Subject</th><th>Score</th><th>Date</th><th>Action</th></tr></thead><tbody>${rows}</tbody></table>`;
}

async function addResult() {
  const student_id = document.getElementById('resultStudent').value;
  const subject = document.getElementById('subject').value.trim();
  const score = document.getElementById('score').value;
  if (!student_id || !subject || score === '') return false;
  const r = await api('add_result', {student_id, subject, score});
  if (r.success) { document.getElementById('subject').value=''; document.getElementById('score').value=''; loadResults(); }
  else {
    if (r.need_login) { alert('Please login first'); await loadCurrentUser(); }
    else alert('Error: ' + r.message);
  }
  return false;
}

function editResult(id, subject, scoreEnc) {
  const sc = decodeURIComponent(scoreEnc);
  const sub = prompt('Subject', subject);
  if (sub === null) return;
  const score = prompt('Score', sc);
  if (score === null) return;
  api('update_result', {id, subject: sub.trim(), score}).then(r => {
    if (r.success) loadResults(); else alert('Error: ' + r.message);
  });
}

async function deleteResult(id) {
  if (!confirm('Delete result?')) return;
  const r = await api('delete_result', {id});
  if (r.success) loadResults();
  else alert('Error: ' + r.message);
}

function downloadResult(id) {
  // open new tab to trigger PDF download from server endpoint
  window.open('?action=download_result_pdf&id=' + encodeURIComponent(id), '_blank');
}

// Utility
function escapeHtml(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// initial load
loadCurrentUser();
loadClasses();
loadStudents();
loadResults();
loadClassesIntoSelect();
loadStudentsIntoSelect();
</script>
</body>
</html>