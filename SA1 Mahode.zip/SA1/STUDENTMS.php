

<?php
declare(strict_types=1);
session_start();

// -------------------- Configuration --------------------
$dbHost = '127.0.0.1';
$dbName = 'studentmanagement system';
$dbUser = 'root';
$dbPass = 'mahode12345';
$dsn = "mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

// -------------------- Connect & ensure schema --------------------
try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, $options);
} catch (PDOException $e) {
    header('Content-Type: text/plain; charset=utf-8', true, 500);
    echo "Database connection failed: " . $e->getMessage();
    exit;
}

// Create tables
$pdo->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','student') NOT NULL DEFAULT 'student',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL
);
$pdo->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS classes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  user_id INT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL
);
$pdo->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(255) NOT NULL,
  student_identifier VARCHAR(100) NOT NULL,
  email VARCHAR(255) DEFAULT NULL,
  dob DATE DEFAULT NULL,
  course VARCHAR(255) DEFAULT NULL,
  enrollment_date DATE DEFAULT NULL,
  class_id INT DEFAULT NULL,
  user_id INT DEFAULT NULL,
  FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE SET NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL
);
$pdo->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS results (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  subject VARCHAR(255) NOT NULL,
  score DECIMAL(10,2) DEFAULT NULL,
  taken_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  user_id INT DEFAULT NULL,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL
);

// -------------------- Helpers --------------------
function jsonResponse($data) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

function currentUserId(): ?int {
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
}

function currentUsername(): ?string {
    return $_SESSION['username'] ?? null;
}

function currentUserRole(): ?string {
    return $_SESSION['role'] ?? null;
}

function requireAuth() {
    if (!currentUserId()) jsonResponse(['success'=>false, 'message'=>'Authentication required', 'need_login' => true]);
}

function requireAdmin() {
    requireAuth();
    if (currentUserRole() !== 'admin') jsonResponse(['success'=>false, 'message'=>'Admin only', 'not_authorized' => true]);
}

// -------------------- API --------------------
$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? '';

if ($action !== '') {
    try {
        // Use $pdo in closures
        global $pdo;

        // Register: if no users exist yet, first registrant becomes admin.
        if ($action === 'register' && $method === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            if ($username === '' || $password === '') jsonResponse(['success'=>false,'message'=>'Username and password required']);
            // check exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) jsonResponse(['success'=>false,'message'=>'Username already taken']);
            // determine role: make first user admin automatically
            $count = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
            $role = $count === 0 ? 'admin' : 'student';
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)");
            $stmt->execute([$username, $hash, $role]);
            $id = (int)$pdo->lastInsertId();
            $_SESSION['user_id'] = $id;
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $role;
            jsonResponse(['success'=>true, 'id'=>$id, 'username'=>$username, 'role'=>$role]);
        }

        if ($action === 'login' && $method === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            if ($username === '' || $password === '') jsonResponse(['success'=>false,'message'=>'Username and password required']);
            $stmt = $pdo->prepare("SELECT id, password_hash, role FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $u = $stmt->fetch();
            if (!$u || !password_verify($password, $u['password_hash'])) jsonResponse(['success'=>false,'message'=>'Invalid credentials']);
            $_SESSION['user_id'] = (int)$u['id'];
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $u['role'];
            jsonResponse(['success'=>true, 'id'=>$u['id'], 'username'=>$username, 'role'=>$u['role']]);
        }

        if ($action === 'logout' && $method === 'POST') {
            session_unset();
            session_destroy();
            jsonResponse(['success'=>true]);
        }

        if ($action === 'me') {
            $uid = currentUserId();
            if (!$uid) jsonResponse(['success'=>true,'user'=>null]);
            jsonResponse(['success'=>true,'user'=>['id'=>$uid,'username'=>currentUsername(),'role'=>currentUserRole()]]);
        }

        // PDF download: admin can download any, student only their own student record results
        if ($action === 'download_result_pdf' && $method === 'GET') {
            requireAuth();
            $uid = currentUserId();
            $id = (int)($_GET['id'] ?? 0);
            if (!$id) { header('Content-Type: text/plain; charset=utf-8', true, 400); echo 'Invalid id'; exit; }
            $stmt = $pdo->prepare("SELECT r.*, s.full_name, s.student_identifier, s.email, s.dob, s.course, s.enrollment_date, s.user_id AS s_user_id FROM results r JOIN students s ON r.student_id = s.id WHERE r.id = ?");
            $stmt->execute([$id]);
            $res = $stmt->fetch();
            if (!$res) { header('Content-Type: text/plain; charset=utf-8', true, 404); echo 'Result not found'; exit; }
            // Permission
            if (currentUserRole() !== 'admin' && (int)$res['s_user_id'] !== $uid) { header('Content-Type: text/plain; charset=utf-8', true, 403); echo 'Not authorized'; exit; }
            // Build lines
            $lines = [];
            $lines[] = 'Student: ' . ($res['full_name'] ?? '—');
            $lines[] = 'Student ID: ' . ($res['student_identifier'] ?? '—');
            $lines[] = 'Email: ' . ($res['email'] ?? '—');
            $lines[] = 'Date of birth: ' . ($res['dob'] ?? '—');
            $lines[] = 'Course: ' . ($res['course'] ?? '—');
            $lines[] = 'Enrollment date: ' . ($res['enrollment_date'] ?? '—');
            $lines[] = '';
            $lines[] = 'Subject: ' . ($res['subject'] ?? '—');
            $lines[] = 'Score: ' . (isset($res['score']) ? $res['score'] : '—');
            $lines[] = 'Taken at: ' . ($res['taken_at'] ?? '—');
            // reuse simple PDF generator from original file (kept minimal)
            function pdfEscape($s) { return str_replace(['\\','(' ,')'], ['\\\\','\\(', '\\)'], $s); }
            function createSimplePdf(string $title, array $lines): string {
                $y = 760; $lineHeight = 14;
                $contentLines = ["BT /F1 12 Tf 50 $y Td (" . pdfEscape($title) . ") Tj"];
                $y -= $lineHeight + 6;
                foreach ($lines as $ln) { $contentLines[] = "0 -$lineHeight TD (" . pdfEscape($ln) . ") Tj"; }
                $content = implode("\n", $contentLines) . "\nET\n";
                $contentStream = $content;
                $len = strlen($contentStream);
                $pdf = "%PDF-1.1\n";
                $pdf .= "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
                $pdf .= "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n";
                $pdf .= "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\nendobj\n";
                $pdf .= "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n";
                $pdf .= "5 0 obj\n<< /Length " . $len . " >>\nstream\n" . $contentStream . "\nendstream\nendobj\n";
                $xrefPos = strlen($pdf);
                $pdf .= "xref\n0 6\n0000000000 65535 f \n";
                for ($i=1;$i<=5;$i++) {
                    $pos = strpos($pdf, "$i 0 obj");
                    $pdf .= str_pad((string)($pos !== false ? $pos : 0), 10, '0', STR_PAD_LEFT) . " 00000 n \n";
                }
                $pdf .= "trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n" . $xrefPos . "\n%%EOF";
                return $pdf;
            }
            $pdf = createSimplePdf('Grade Report', $lines);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="grade_' . $id . '.pdf"');
            echo $pdf;
            exit;
        }

        // From here require auth
        requireAuth();
        $uid = currentUserId();
        $urole = currentUserRole();

        // -------------------- Classes --------------------
        if ($action === 'list_classes') {
            // admin sees all classes, non-admin sees only classes they created
            if ($urole === 'admin') {
                $stmt = $pdo->query("SELECT * FROM classes ORDER BY name ASC");
                $classes = $stmt->fetchAll();
            } else {
                $stmt = $pdo->prepare("SELECT * FROM classes WHERE user_id = ? ORDER BY name ASC");
                $stmt->execute([$uid]);
                $classes = $stmt->fetchAll();
            }
            jsonResponse(['success'=>true,'classes'=>$classes]);
        }

        if ($action === 'add_class' && $method === 'POST') {
            requireAdmin();
            $name = trim($_POST['name'] ?? '');
            if ($name === '') jsonResponse(['success'=>false,'message'=>'Class name required']);
            // uniqueness per admin
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM classes WHERE user_id = ? AND LOWER(name) = LOWER(?)");
            $stmt->execute([$uid, $name]);
            if ((int)$stmt->fetchColumn() > 0) jsonResponse(['success'=>false,'message'=>'Class already exists']);
            $stmt = $pdo->prepare("INSERT INTO classes (name, user_id) VALUES (?, ?)");
            $stmt->execute([$name, $uid]);
            jsonResponse(['success'=>true,'id'=> (int)$pdo->lastInsertId()]);
        }

        if ($action === 'delete_class' && $method === 'POST') {
            requireAdmin();
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) jsonResponse(['success'=>false,'message'=>'Invalid id']);
            // ensure class belongs to admin
            $stmt = $pdo->prepare("SELECT user_id FROM classes WHERE id = ?");
            $stmt->execute([$id]);
            $c = $stmt->fetch();
            if (!$c) jsonResponse(['success'=>false,'message'=>'Class not found']);
            if ((int)$c['user_id'] !== $uid) jsonResponse(['success'=>false,'message'=>'Not authorized']);
            // Delete class; students' class_id will be set to NULL due to FK action
            $stmt = $pdo->prepare("DELETE FROM classes WHERE id = ?");
            $stmt->execute([$id]);
            jsonResponse(['success'=>true]);
        }

        // -------------------- Students (CRUD) --------------------
        if ($action === 'list_students') {
            // Admin sees all students; student user sees their own student record (linked via students.user_id)
            if ($urole === 'admin') {
                $stmt = $pdo->query("SELECT s.*, c.name AS class_name FROM students s LEFT JOIN classes c ON s.class_id = c.id ORDER BY s.full_name ASC");
                $students = $stmt->fetchAll();
            } else {
                $stmt = $pdo->prepare("SELECT s.*, c.name AS class_name FROM students s LEFT JOIN classes c ON s.class_id = c.id WHERE s.user_id = ? ORDER BY s.full_name ASC");
                $stmt->execute([$uid]);
                $students = $stmt->fetchAll();
            }
            jsonResponse(['success'=>true,'students'=>$students]);
        }

        if ($action === 'add_student' && $method === 'POST') {
            // Only admin creates student records
            requireAdmin();
            $full_name = trim($_POST['full_name'] ?? '');
            $student_identifier = trim($_POST['student_identifier'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $dob = trim($_POST['dob'] ?? '') ?: null;
            $course = trim($_POST['course'] ?? '') ?: null;
            $enrollment_date = trim($_POST['enrollment_date'] ?? '') ?: null;
            $class_id = isset($_POST['class_id']) && $_POST['class_id'] !== '' ? (int)$_POST['class_id'] : null;
            if ($full_name === '' || $student_identifier === '') jsonResponse(['success'=>false,'message'=>'Full name and Student ID required']);
            // validate class if provided
            if ($class_id !== null) {
                $stmt = $pdo->prepare("SELECT id, user_id FROM classes WHERE id = ?");
                $stmt->execute([$class_id]);
                $cl = $stmt->fetch();
                if (!$cl) jsonResponse(['success'=>false,'message'=>'Class not found']);
                if ((int)$cl['user_id'] !== $uid) jsonResponse(['success'=>false,'message'=>'Not authorized for class']);
            }
            $stmt = $pdo->prepare("INSERT INTO students (full_name, student_identifier, email, dob, course, enrollment_date, class_id, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$full_name, $student_identifier, $email ?: null, $dob, $course, $enrollment_date, $class_id, $uid]);
            jsonResponse(['success'=>true,'id'=>(int)$pdo->lastInsertId()]);
        }

        if ($action === 'update_student' && $method === 'POST') {
            requireAdmin();
            $id = (int)($_POST['id'] ?? 0);
            $full_name = trim($_POST['full_name'] ?? '');
            $student_identifier = trim($_POST['student_identifier'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $dob = trim($_POST['dob'] ?? '') ?: null;
            $course = trim($_POST['course'] ?? '') ?: null;
            $enrollment_date = trim($_POST['enrollment_date'] ?? '') ?: null;
            $class_id = isset($_POST['class_id']) && $_POST['class_id'] !== '' ? (int)$_POST['class_id'] : null;
            if (!$id || $full_name === '' || $student_identifier === '') jsonResponse(['success'=>false,'message'=>'Invalid data']);
            $stmt = $pdo->prepare("SELECT user_id FROM students WHERE id = ?");
            $stmt->execute([$id]);
            $s = $stmt->fetch();
            if (!$s) jsonResponse(['success'=>false,'message'=>'Student not found']);
            // admin can update any student (spec says admin modifies existing student records)
            if ($class_id !== null) {
                $stmt = $pdo->prepare("SELECT id, user_id FROM classes WHERE id = ?");
                $stmt->execute([$class_id]);
                $cl = $stmt->fetch();
                if (!$cl) jsonResponse(['success'=>false,'message'=>'Class not found']);
            }
            $stmt = $pdo->prepare("UPDATE students SET full_name = ?, student_identifier = ?, email = ?, dob = ?, course = ?, enrollment_date = ?, class_id = ? WHERE id = ?");
            $stmt->execute([$full_name, $student_identifier, $email ?: null, $dob, $course, $enrollment_date, $class_id, $id]);
            jsonResponse(['success'=>true]);
        }

        if ($action === 'delete_student' && $method === 'POST') {
            requireAdmin();
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) jsonResponse(['success'=>false,'message'=>'Invalid id']);
            $stmt = $pdo->prepare("SELECT id FROM students WHERE id = ?");
            $stmt->execute([$id]);
            if (!$stmt->fetch()) jsonResponse(['success'=>false,'message'=>'Student not found']);
            // cascade delete results due to FK
            $stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
            $stmt->execute([$id]);
            jsonResponse(['success'=>true]);
        }

        // -------------------- Results --------------------
        if ($action === 'list_results') {
            // Admin sees all results with student info; students see only their own results (if their user attached to student)
            if ($urole === 'admin') {
                $stmt = $pdo->query("SELECT r.*, s.full_name AS student_name, s.student_identifier, c.name AS class_name FROM results r JOIN students s ON r.student_id = s.id LEFT JOIN classes c ON s.class_id = c.id ORDER BY r.taken_at DESC");
                $results = $stmt->fetchAll();
            } else {
                // find student ids that belong to current user
                $stmt = $pdo->prepare("SELECT id FROM students WHERE user_id = ?");
                $stmt->execute([$uid]);
                $sids = $stmt->fetchAll(PDO::FETCH_COLUMN);
                if (!$sids) $results = [];
                else {
                    $in = implode(',', array_fill(0, count($sids), '?'));
                    $stmt = $pdo->prepare("SELECT r.*, s.full_name AS student_name, s.student_identifier, c.name AS class_name FROM results r JOIN students s ON r.student_id = s.id LEFT JOIN classes c ON s.class_id = c.id WHERE r.student_id IN ($in) ORDER BY r.taken_at DESC");
                    $stmt->execute($sids);
                    $results = $stmt->fetchAll();
                }
            }
            jsonResponse(['success'=>true,'results'=>$results]);
        }

        if ($action === 'add_result' && $method === 'POST') {
            // Admin only (teachers/admins); adapt if required
            requireAdmin();
            $student_id = (int)($_POST['student_id'] ?? 0);
            $subject = trim($_POST['subject'] ?? '');
            $score = $_POST['score'] !== '' ? (float)$_POST['score'] : null;
            if (!$student_id || $subject === '' || $score === null) jsonResponse(['success'=>false,'message'=>'Invalid data']);
            $stmt = $pdo->prepare("SELECT id FROM students WHERE id = ?");
            $stmt->execute([$student_id]);
            if (!$stmt->fetch()) jsonResponse(['success'=>false,'message'=>'Student not found']);
            $stmt = $pdo->prepare("INSERT INTO results (student_id, subject, score, taken_at, user_id) VALUES (?, ?, ?, NOW(), ?)");
            $stmt->execute([$student_id, $subject, $score, $uid]);
            jsonResponse(['success'=>true,'id'=>(int)$pdo->lastInsertId()]);
        }

        if ($action === 'update_result' && $method === 'POST') {
            requireAdmin();
            $id = (int)($_POST['id'] ?? 0);
            $subject = trim($_POST['subject'] ?? '');
            $score = $_POST['score'] !== '' ? (float)$_POST['score'] : null;
            if (!$id || $subject === '' || $score === null) jsonResponse(['success'=>false,'message'=>'Invalid data']);
            $stmt = $pdo->prepare("SELECT id FROM results WHERE id = ?");
            $stmt->execute([$id]);
            if (!$stmt->fetch()) jsonResponse(['success'=>false,'message'=>'Result not found']);
            $stmt = $pdo->prepare("UPDATE results SET subject = ?, score = ? WHERE id = ?");
            $stmt->execute([$subject, $score, $id]);
            jsonResponse(['success'=>true]);
        }

        if ($action === 'delete_result' && $method === 'POST') {
            requireAdmin();
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) jsonResponse(['success'=>false,'message'=>'Invalid id']);
            $stmt = $pdo->prepare("SELECT id FROM results WHERE id = ?");
            $stmt->execute([$id]);
            if (!$stmt->fetch()) jsonResponse(['success'=>false,'message'=>'Result not found']);
            $stmt = $pdo->prepare("DELETE FROM results WHERE id = ?");
            $stmt->execute([$id]);
            jsonResponse(['success'=>true]);
        }

        jsonResponse(['success'=>false,'message'=>'Unknown action']);
    } catch (Throwable $e) {
        jsonResponse(['success'=>false,'message'=>$e->getMessage()]);
    }
}

// -------------------- Render HTML UI (unchanged client side) --------------------
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Student Management System (MySQL)</title>
<meta name="viewport" content="width=device-width,initial-scale=1" />
<style>
/* Keep the same styles as original for brevity */
:root{ --bg:#071726; --panel:#0e2a45; --muted:#9fb8cf; --accent:#d43a3a; --accent-2:#ff5a5a; --text:#e8f3fb; --border:rgba(255,255,255,0.06); --glass:rgba(255,255,255,0.02); --success:#4fc08d;}
*{box-sizing:border-box}html,body{height:100%}body{font-family:"Segoe UI", Roboto, Arial, sans-serif;background:linear-gradient(180deg,var(--bg) 0%,#031021 100%);color:var(--text);max-width:1000px;margin:20px auto;padding:18px;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}
header{display:flex;justify-content:space-between;align-items:center;padding:14px;background:linear-gradient(90deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));border:1px solid var(--border);border-radius:8px;box-shadow:0 6px 18px rgba(2,10,20,0.6);}h1{margin:0;color:var(--text);font-size:1.25rem}.small{color:var(--muted)}
.tabs{margin-top:16px;display:flex;gap:8px}.tabs button{background:transparent;color:var(--muted);border:1px solid transparent;padding:8px 12px;border-radius:6px;cursor:pointer;transition:all .18s ease;font-weight:600}.tabs button:hover{color:var(--text);background:rgba(255,255,255,0.02);box-shadow:0 4px 10px rgba(2,10,20,0.6)}.tabs button.active,.tabs button:focus{color:var(--text);background:linear-gradient(180deg, rgba(212,58,58,0.12), rgba(212,58,58,0.06));border:1px solid rgba(212,58,58,0.18);outline:none}
section{margin-top:12px;background:linear-gradient(180deg,var(--panel),rgba(14,42,69,0.9));padding:14px;border-radius:8px;border:1px solid var(--border);box-shadow:0 8px 24px rgba(2,10,20,0.6)}
form{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}input, select{background:var(--glass);color:var(--text);border:1px solid rgba(255,255,255,0.04);padding:8px 10px;border-radius:6px;min-height:36px;transition:box-shadow .12s ease, border-color .12s ease}input:focus, select:focus{outline:none;box-shadow:0 4px 16px rgba(2,10,20,0.6);border-color:rgba(212,58,58,0.6)}
.btn, button{background:linear-gradient(180deg,var(--accent),var(--accent-2));color:white;border:none;padding:8px 12px;border-radius:6px;cursor:pointer;font-weight:700;box-shadow:0 6px 18px rgba(212,58,58,0.12);transition:transform .08s ease, box-shadow .12s ease, opacity .12s ease} .btn:hover, button:hover{ transform: translateY(-1px); opacity:0.98 } button[disabled]{ opacity:0.5; cursor:not-allowed }
#authArea button{background:transparent;border:1px solid rgba(255,255,255,0.04);color:var(--muted);padding:6px 8px;border-radius:6px;}#authArea button:hover{ color:var(--text); border-color:rgba(212,58,58,0.14) }
table{width:100%;border-collapse:collapse;margin-top:8px;background:transparent;color:var(--text)}th, td{padding:10px 12px;border-bottom:1px solid rgba(255,255,255,0.03);text-align:left;vertical-align:middle}thead th{background:linear-gradient(90deg, rgba(255,255,255,0.02), rgba(0,0,0,0.04));font-size:0.95em;color:var(--muted);border-bottom:1px solid rgba(255,255,255,0.04)}tbody tr:nth-child(odd){ background: rgba(255,255,255,0.01) }tbody tr:hover{ background: rgba(212,58,58,0.03) }
table button{background:transparent;border:1px solid rgba(255,255,255,0.06);color:var(--text);padding:6px 8px;border-radius:6px;font-weight:600}table button:hover{background: rgba(212,58,58,0.12);border-color: rgba(212,58,58,0.2);color:#fff}
@media (max-width:720px){body{padding:12px}form{flex-direction:column;align-items:stretch}.tabs{flex-wrap:wrap}th,td{padding:8px}}
</style>
</head>
<header>
  <h1>Student Management System (MySQL)</h1>
  <div>
    <span class="small"> Welcome</span>
    <span id="authArea" class="small" style="margin-left:12px"></span>
  </div>
</header>

<div class="tabs">
    <button onclick="show('classes')">Classes</button>
    <button onclick="show('students')">Students</button>
    <button onclick="show('results')">Results</button>
    <button onclick="showAll()">All</button>
</div>

<!-- Classes -->
<section id="classes" style="display:block">
    <h2>Classes</h2>
    <form id="classForm" onsubmit="return addClass();">
        <input name="name" id="className" placeholder="Class name (e.g., Grade 10)" required />
        <button class="btn" type="submit">Add Class</button>
    </form>
    <div id="classesList">Loading classes...</div>
</section>

<!-- Students -->
<section id="students" style="display:none">
    <h2>Students</h2>
    <form id="studentForm" onsubmit="return addStudent();">
        <input id="fullName" placeholder="Full name" required />
        <input id="studentIdentifier" placeholder="Student ID" required />
        <input id="email" placeholder="Email" type="email" />
        <input id="dob" placeholder="Date of Birth (YYYY-MM-DD)" />
        <input id="course" placeholder="Course of Study" />
        <input id="enrollmentDate" placeholder="Enrollment Date (YYYY-MM-DD)" />
        <select id="studentClass"><option value="">-- No class --</option></select>
        <button class="btn" type="submit">Add Student</button>
    </form>
    <div id="studentsList">Loading students...</div>
</section>

<!-- Results -->
<section id="results" style="display:none">
    <h2>Results</h2>
    <form id="resultForm" onsubmit="return addResult();">
        <select id="resultStudent" required><option value="">Select student</option></select>
        <input id="subject" placeholder="Subject" required />
        <input id="score" type="number" step="0.01" placeholder="Score" required />
        <button class="btn" type="submit">Add Result</button>
    </form>
    <div id="resultsList">Loading results...</div>
</section>

<!-- All: combined view of students with full details and their results -->
<section id="all" style="display:none">
    <h2>All Students (Full Information)</h2>
    <div id="allList">Loading all information...</div>
</section>

<script>
// JS helper fetch
async function api(action, data = null) {
  const opts = data ? { method: 'POST', body: new URLSearchParams(Object.assign({action}, data)) } : { method: 'GET' };
  const url = data ? '' : '?action=' + encodeURIComponent(action);
  const res = await fetch(url, opts);
  return res.json();
}

function show(name) {
  ['classes','students','results'].forEach(n => document.getElementById(n).style.display = (n===name ? 'block' : 'none'));
  if (name === 'classes') loadClasses();
  if (name === 'students') { loadStudents(); loadClassesIntoSelect(); }
  if (name === 'results') { loadResults(); loadStudentsIntoSelect(); }
}

async function loadCurrentUser() {
  const r = await api('me');
  const auth = document.getElementById('authArea');
  if (!r.success || !r.user) {
    auth.innerHTML = '<button onclick="loginPrompt()">Login</button><button onclick="registerPrompt()">Register</button>';
  } else {
    auth.innerHTML = `Hello, ${escapeHtml(r.user.username)} (${escapeHtml(r.user.role)}) <button onclick="logout()">Logout</button>`;
  }
}

async function loginPrompt() {
  const username = prompt('Username');
  if (username === null) return;
  const password = prompt('Password');
  if (password === null) return;
  const r = await api('login', {username, password});
  if (r.success) {
    await loadCurrentUser();
    loadClasses(); loadStudents(); loadResults();
  } else alert('Error: ' + r.message);
}

async function registerPrompt() {
  const username = prompt('Choose username');
  if (username === null) return;
  const password = prompt('Choose password');
  if (password === null) return;
  const r = await api('register', {username, password});
  if (r.success) {
    await loadCurrentUser();
    loadClasses(); loadStudents(); loadResults();
  } else alert('Error: ' + r.message);
}

async function logout() {
  await api('logout', {});
  await loadCurrentUser();
  loadClasses(); loadStudents(); loadResults();
}

// Classes
async function loadClasses() {
  const r = await api('list_classes');
  const container = document.getElementById('classesList');
  if (!r.success) { container.textContent = 'Error: ' + r.message; return; }
  const rows = r.classes.map(c => `<tr><td>${escapeHtml(c.name)}</td>
    <td><button onclick="deleteClass(${c.id})">Delete</button></td></tr>`).join('');
  container.innerHTML = `<table><thead><tr><th>Name</th><th>Action</th></tr></thead><tbody>${rows}</tbody></table>`;
  loadClassesIntoSelect();
}

async function addClass() {
  const name = document.getElementById('className').value.trim();
  if (!name) return false;
  const r = await api('add_class', {name});
  if (r.success) { document.getElementById('className').value=''; loadClasses(); }
  else {
    if (r.need_login) { alert('Please login first'); await loadCurrentUser(); }
    else alert('Error: ' + r.message);
  }
  return false;
}

async function deleteClass(id) {
  if (!confirm('Delete class? Students in this class will be set to no class.')) return;
  const r = await api('delete_class', {id});
  if (r.success) loadClasses();
  else alert('Error: ' + r.message);
}

async function loadClassesIntoSelect() {
  const r = await api('list_classes');
  const sel1 = document.getElementById('studentClass');
  if (!r.success) return;
  sel1.innerHTML = '<option value="">-- No class --</option>' + r.classes.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');
}

// Students
async function loadStudents() {
  const r = await api('list_students');
  const container = document.getElementById('studentsList');
  if (!r.success) { container.textContent = 'Error: ' + r.message; return; }
  const rows = r.students.map(s => `<tr>
    <td>${escapeHtml(s.full_name)}<div class="small">${escapeHtml(s.student_identifier||'')}</div></td>
    <td>${escapeHtml(s.class_name||'—')}<div class="small">${escapeHtml(s.course||'')}</div></td>
    <td>
      <button onclick="editStudent(${s.id},${JSON.stringify(s.full_name)},${JSON.stringify(s.student_identifier)},${JSON.stringify(s.email)},${JSON.stringify(s.dob)},${JSON.stringify(s.course)},${JSON.stringify(s.enrollment_date)},${s.class_id??'null'})">Edit</button>
      <button onclick="deleteStudent(${s.id})">Delete</button>
    </td>
    </tr>`).join('');
  container.innerHTML = `<table><thead><tr><th>Name / ID</th><th>Class / Course</th><th>Action</th></tr></thead><tbody>${rows}</tbody></table>`;
  loadStudentsIntoSelect();
}

async function addStudent() {
  const full_name = document.getElementById('fullName').value.trim();
  const student_identifier = document.getElementById('studentIdentifier').value.trim();
  const email = document.getElementById('email').value.trim();
  const dob = document.getElementById('dob').value.trim();
  const course = document.getElementById('course').value.trim();
  const enrollment_date = document.getElementById('enrollmentDate').value.trim();
  const class_id = document.getElementById('studentClass').value;
  if (!full_name || !student_identifier) return false;
  const r = await api('add_student', {full_name, student_identifier, email, dob, course, enrollment_date, class_id});
  if (r.success) {
    document.getElementById('fullName').value=''; document.getElementById('studentIdentifier').value='';
    document.getElementById('email').value=''; document.getElementById('dob').value='';
    document.getElementById('course').value=''; document.getElementById('enrollmentDate').value='';
    loadStudents();
  }
  else {
    if (r.need_login) { alert('Please login first'); await loadCurrentUser(); }
    else alert('Error: ' + r.message);
  }
  return false;
}

function editStudent(id, fullName, studentId, email, dob, course, enrollmentDate, classId) {
  const fn = prompt('Full name', fullName);
  if (fn === null) return;
  const sid = prompt('Student ID', studentId);
  if (sid === null) return;
  const em = prompt('Email', email ?? '');
  if (em === null) return;
  const db = prompt('Date of Birth (YYYY-MM-DD)', dob ?? '');
  if (db === null) return;
  const cr = prompt('Course of Study', course ?? '');
  if (cr === null) return;
  const ed = prompt('Enrollment Date (YYYY-MM-DD)', enrollmentDate ?? '');
  if (ed === null) return;
  const cid = prompt('Class ID (empty for none)', classId === null ? '' : classId);
  api('update_student', {
    id, full_name: fn.trim(), student_identifier: sid.trim(),
    email: em.trim(), dob: db.trim(), course: cr.trim(), enrollment_date: ed.trim(), class_id: cid
  }).then(r => {
    if (r.success) loadStudents(); else alert('Error: ' + r.message);
  });
}

async function deleteStudent(id) {
  if (!confirm('Delete student and all their results?')) return;
  const r = await api('delete_student', {id});
  if (r.success) loadStudents();
  else alert('Error: ' + r.message);
}

async function loadStudentsIntoSelect() {
  const r = await api('list_students');
  const sel = document.getElementById('resultStudent');
  if (!r.success) return;
  sel.innerHTML = '<option value="">Select student</option>' + r.students.map(s => `<option value="${s.id}">${escapeHtml(s.full_name)} (${escapeHtml(s.student_identifier||'')})${s.class_name? ' — '+escapeHtml(s.class_name):''}</option>`).join('');
}

// Results
async function loadResults() {
  const r = await api('list_results');
  const container = document.getElementById('resultsList');
  if (!r.success) { container.textContent = 'Error: ' + r.message; return; }
  const rows = r.results.map(rw => `<tr>
    <td>${escapeHtml(rw.student_name)}</td>
    <td>${escapeHtml(rw.class_name||'—')}</td>
    <td>${escapeHtml(rw.subject)}</td>
    <td>${Number(rw.score)}</td>
    <td>${escapeHtml(rw.taken_at)}</td>
    <td>
      <button onclick="editResult(${rw.id},${JSON.stringify(rw.subject)},${encodeURIComponent(rw.score)})">Edit</button>
      <button onclick="deleteResult(${rw.id})">Delete</button>
      <button onclick="downloadResult(${rw.id})">Download PDF</button>
    </td>
  </tr>`).join('');
  container.innerHTML = `<table><thead><tr><th>Student</th><th>Class</th><th>Subject</th><th>Score</th><th>Date</th><th>Action</th></tr></thead><tbody>${rows}</tbody></table>`;
}

async function addResult() {
  const student_id = document.getElementById('resultStudent').value;
  const subject = document.getElementById('subject').value.trim();
  const score = document.getElementById('score').value;
  if (!student_id || !subject || score === '') return false;
  const r = await api('add_result', {student_id, subject, score});
  if (r.success) { document.getElementById('subject').value=''; document.getElementById('score').value=''; loadResults(); }
  else {
    if (r.need_login) { alert('Please login first'); await loadCurrentUser(); }
    else alert('Error: ' + r.message);
  }
  return false;
}

function editResult(id, subject, scoreEnc) {
  const sc = decodeURIComponent(scoreEnc);
  const sub = prompt('Subject', subject);
  if (sub === null) return;
  const score = prompt('Score', sc);
  if (score === null) return;
  api('update_result', {id, subject: sub.trim(), score}).then(r => {
    if (r.success) loadResults(); else alert('Error: ' + r.message);
  });
}

async function deleteResult(id) {
  if (!confirm('Delete result?')) return;
  const r = await api('delete_result', {id});
  if (r.success) loadResults();
  else alert('Error: ' + r.message);
}

function downloadResult(id) {
  // open new tab to trigger PDF download from server endpoint
  window.open('?action=download_result_pdf&id=' + encodeURIComponent(id), '_blank');
}

// All combined view
function showAll() {
    document.getElementById('classes').style.display = 'none';
    document.getElementById('students').style.display = 'none';
    document.getElementById('results').style.display = 'none';
    document.getElementById('all').style.display = 'block';
    loadAll();
}
async function loadAll() {
    const [rsResults, rsStudents, rsClasses] = await Promise.allSettled([
        api('list_results'),
        api('list_students'),
        api('list_classes')
    ]);
    const stRes = rsStudents.status === 'fulfilled' ? rsStudents.value : null;
    if (!stRes || !stRes.success) {
        document.getElementById('allList').textContent = 'Error loading students: ' + (stRes && stRes.message ? stRes.message : 'Request failed');
        return;
    }
    const students = stRes.students || [];
    const results = (rsResults.status === 'fulfilled' && rsResults.value && rsResults.value.success) ? rsResults.value.results : [];
    const classes = (rsClasses.status === 'fulfilled' && rsClasses.value && rsClasses.value.success) ? rsClasses.value.classes : [];
    const classNames = {};
    classes.forEach(c => { classNames[c.id] = c.name; });
    const resByStudent = {};
    (results || []).forEach(r => {
        const sid = Number(r.student_id);
        if (!resByStudent[sid]) resByStudent[sid] = [];
        resByStudent[sid].push(r);
    });
    const rows = students.map(s => {
        const sid = s.id;
        const clsName = s.class_name || (s.class_id ? (classNames[s.class_id] || '') : '');
        const resultsHtml = (resByStudent[sid] || []).map(rr =>
            `<div class="small">${escapeHtml(rr.subject)} — ${escapeHtml(String(rr.score))} (${escapeHtml(rr.taken_at)})</div>`
        ).join('') || '<div class="small">No results</div>';
        return `<tr>
            <td>${escapeHtml(s.full_name)}<div class="small">${escapeHtml(s.student_identifier||'')}</div></td>
            <td>${escapeHtml(s.email||'')}</td>
            <td>${escapeHtml(s.dob||'')}</td>
            <td>${escapeHtml(s.course||'')}</td>
            <td>${escapeHtml(s.enrollment_date||'')}</td>
            <td>${escapeHtml(clsName || '—')}</td>
            <td>${resultsHtml}</td>
        </tr>`;
    }).join('');
    document.getElementById('allList').innerHTML =
        `<table>
             <thead>
                 <tr>
                     <th>Name / ID</th>
                     <th>Email</th>
                     <th>DOB</th>
                     <th>Course</th>
                     <th>Enrollment</th>
                     <th>Class</th>
                     <th>Results</th>
                 </tr>
             </thead>
             <tbody>${rows}</tbody>
         </table>`;
}

// Utility
function escapeHtml(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// initial load
loadCurrentUser();
loadClasses();
loadStudents();
loadResults();
loadClassesIntoSelect();
loadStudentsIntoSelect();
</script>
</body>
</html>
